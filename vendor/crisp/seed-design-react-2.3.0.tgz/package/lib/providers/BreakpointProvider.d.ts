import { Breakpoint } from '@seed-design/css/breakpoints';
import type * as React from "react";
export interface BreakpointProviderProps {
    defaultBreakpoint?: Breakpoint;
    children: React.ReactNode;
}
export declare function BreakpointProvider({ defaultBreakpoint, children, }: BreakpointProviderProps): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=BreakpointProvider.d.ts.map