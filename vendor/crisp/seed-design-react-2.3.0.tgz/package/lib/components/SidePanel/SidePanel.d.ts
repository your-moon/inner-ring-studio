import { SidePanelVariantProps } from '@seed-design/css/recipes/side-panel';
import { Drawer } from '@seed-design/react-drawer';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { StyleProps } from '../../utils/styled';
import * as React from "react";
export interface SidePanelRootProps extends SidePanelVariantProps, Pick<Drawer.RootProps, "children" | "open" | "defaultOpen" | "onOpenChange" | "modal" | "dismissible" | "closeOnEscape" | "closeOnInteractOutside" | "lazyMount" | "unmountOnExit" | "onAnimationEnd"> {
    /** Direction the side panel slides in from. @default "right" */
    direction?: "left" | "right";
}
export declare function SidePanelRoot(props: SidePanelRootProps): import("react/jsx-runtime").JSX.Element;
export interface SidePanelTriggerProps extends Drawer.TriggerProps {
}
export declare const SidePanelTrigger: React.ForwardRefExoticComponent<Drawer.TriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface SidePanelPositionerProps extends Drawer.PositionerProps {
}
export declare const SidePanelPositioner: React.ForwardRefExoticComponent<SidePanelPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface SidePanelBackdropProps extends Drawer.BackdropProps {
}
export declare const SidePanelBackdrop: React.ForwardRefExoticComponent<SidePanelBackdropProps & React.RefAttributes<HTMLDivElement>>;
export interface SidePanelContentProps extends Drawer.ContentProps, Pick<StyleProps, "width" | "maxWidth"> {
}
export declare const SidePanelContent: React.ForwardRefExoticComponent<SidePanelContentProps & React.RefAttributes<HTMLDivElement>>;
export interface SidePanelHeaderProps extends Drawer.HeaderProps {
}
export declare const SidePanelHeader: React.ForwardRefExoticComponent<SidePanelHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface SidePanelTitleProps extends Drawer.TitleProps {
}
export declare const SidePanelTitle: React.ForwardRefExoticComponent<SidePanelTitleProps & React.RefAttributes<HTMLHeadingElement>>;
export interface SidePanelDescriptionProps extends Drawer.DescriptionProps {
}
export declare const SidePanelDescription: React.ForwardRefExoticComponent<SidePanelDescriptionProps & React.RefAttributes<HTMLParagraphElement>>;
export interface SidePanelBodyProps extends PrimitiveProps, Pick<StyleProps, "paddingX" | "height" | "maxHeight" | "minHeight" | "justifyContent" | "alignItems">, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SidePanelBody: React.ForwardRefExoticComponent<SidePanelBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface SidePanelFooterProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SidePanelFooter: React.ForwardRefExoticComponent<SidePanelFooterProps & React.RefAttributes<HTMLDivElement>>;
export interface SidePanelCloseButtonProps extends Drawer.CloseButtonProps {
}
export declare const SidePanelCloseButton: React.ForwardRefExoticComponent<SidePanelCloseButtonProps & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=SidePanel.d.ts.map