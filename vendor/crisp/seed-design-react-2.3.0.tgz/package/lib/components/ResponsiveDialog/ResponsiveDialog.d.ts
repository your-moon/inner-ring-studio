import { Breakpoint } from '@seed-design/css/breakpoints';
import { Drawer } from '@seed-design/react-drawer';
import { BottomSheet } from '../BottomSheet';
import { ContentDialog } from '../ContentDialog';
import * as React from "react";
type SharedProps<ContentDialogProps, BottomSheetProps> = Pick<ContentDialogProps, Extract<keyof ContentDialogProps, keyof BottomSheetProps>> & Pick<BottomSheetProps, Extract<keyof BottomSheetProps, keyof ContentDialogProps>>;
interface ResponsiveDialogContextValue {
    shouldUseBottomSheet: boolean | undefined;
}
export declare function useResponsiveDialogContext(): ResponsiveDialogContextValue;
export interface ResponsiveDialogRootProps {
    children?: React.ReactNode;
    open?: boolean;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    /**
     * Breakpoint at and above which it renders as a Dialog; below it, a
     * BottomSheet. Cannot be `"base"`, which would always be a Dialog.
     * @default "md"
     */
    dialogBreakpoint?: Exclude<Breakpoint, "base">;
    /** Props forwarded to the underlying ContentDialog root (at and above the breakpoint). */
    dialogRootProps?: Omit<ContentDialog.RootProps, "children" | "open" | "defaultOpen" | "onOpenChange">;
    /** Props forwarded to the underlying BottomSheet root (below the breakpoint). */
    bottomSheetRootProps?: Omit<BottomSheet.RootProps, "children" | "open" | "defaultOpen" | "onOpenChange">;
}
export declare const ResponsiveDialogRoot: {
    ({ children, open: openProp, defaultOpen, onOpenChange, dialogBreakpoint, dialogRootProps, bottomSheetRootProps, }: ResponsiveDialogRootProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export interface ResponsiveDialogTriggerProps extends SharedProps<ContentDialog.TriggerProps, BottomSheet.TriggerProps> {
}
export declare const ResponsiveDialogTrigger: React.ForwardRefExoticComponent<ResponsiveDialogTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface ResponsiveDialogPositionerProps extends SharedProps<ContentDialog.PositionerProps, BottomSheet.PositionerProps> {
}
export declare const ResponsiveDialogPositioner: React.ForwardRefExoticComponent<ResponsiveDialogPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveDialogBackdropProps extends SharedProps<ContentDialog.BackdropProps, BottomSheet.BackdropProps> {
}
export declare const ResponsiveDialogBackdrop: React.ForwardRefExoticComponent<ResponsiveDialogBackdropProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveDialogContentProps extends SharedProps<ContentDialog.ContentProps, BottomSheet.ContentProps> {
}
export declare const ResponsiveDialogContent: React.ForwardRefExoticComponent<ResponsiveDialogContentProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveDialogHeaderProps extends SharedProps<ContentDialog.HeaderProps, BottomSheet.HeaderProps> {
}
export declare const ResponsiveDialogHeader: React.ForwardRefExoticComponent<ResponsiveDialogHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveDialogTitleProps extends SharedProps<ContentDialog.TitleProps, BottomSheet.TitleProps> {
}
export declare const ResponsiveDialogTitle: React.ForwardRefExoticComponent<ResponsiveDialogTitleProps & React.RefAttributes<HTMLHeadingElement>>;
export interface ResponsiveDialogDescriptionProps extends SharedProps<ContentDialog.DescriptionProps, BottomSheet.DescriptionProps> {
}
export declare const ResponsiveDialogDescription: React.ForwardRefExoticComponent<ResponsiveDialogDescriptionProps & React.RefAttributes<HTMLParagraphElement>>;
export interface ResponsiveDialogBodyProps extends SharedProps<ContentDialog.BodyProps, BottomSheet.BodyProps> {
}
export declare const ResponsiveDialogBody: React.ForwardRefExoticComponent<ResponsiveDialogBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveDialogFooterProps extends SharedProps<ContentDialog.FooterProps, BottomSheet.FooterProps> {
}
export declare const ResponsiveDialogFooter: React.ForwardRefExoticComponent<ResponsiveDialogFooterProps & React.RefAttributes<HTMLDivElement>>;
/**
 * Unstyled button that closes the dialog or bottom sheet on click, meant to be
 * composed with an action button via `asChild`.
 */
export interface ResponsiveDialogActionProps extends SharedProps<ContentDialog.ActionProps, Drawer.CloseButtonProps> {
}
export declare const ResponsiveDialogAction: React.ForwardRefExoticComponent<ResponsiveDialogActionProps & React.RefAttributes<HTMLButtonElement>>;
export interface ResponsiveDialogCloseButtonProps extends SharedProps<ContentDialog.CloseButtonProps, BottomSheet.CloseButtonProps> {
}
export declare const ResponsiveDialogCloseButton: React.ForwardRefExoticComponent<ResponsiveDialogCloseButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface ResponsiveDialogHandleProps extends BottomSheet.HandleProps {
}
export declare const ResponsiveDialogHandle: React.ForwardRefExoticComponent<ResponsiveDialogHandleProps & React.RefAttributes<HTMLDivElement>>;
export {};
//# sourceMappingURL=ResponsiveDialog.d.ts.map