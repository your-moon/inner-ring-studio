import { DatePickerActions, DatePickerCellState, UseDatePickerProps } from '@seed-design/react-date-picker';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { StyleProps } from '../../utils/styled';
import * as React from "react";
type DatePickerRootProps = PrimitiveProps & Pick<StyleProps, "height" | "minHeight" | "maxHeight"> & Omit<React.HTMLAttributes<HTMLDivElement>, "children" | "defaultValue" | "onChange" | "onValueChange">;
export interface DatePickerCellContentRenderProps extends DatePickerCellState {
}
type DatePickerBehaviorProps = UseDatePickerProps extends infer Props ? Props extends UseDatePickerProps ? Omit<Props, "visibleRange"> : never : never;
type DatePickerCellCustomization = {
    /**
     * 기본 날짜 숫자 아래에 부가 콘텐츠를 추가합니다.
     * 날짜 숫자를 유지하는 대부분의 사례에서는 이 prop을 우선 사용하세요.
     */
    renderDateCellSupplement?: (props: DatePickerCellContentRenderProps) => React.ReactNode;
    renderDateCellContent?: never;
} | {
    /**
     * `renderDateCellSupplement`로 표현할 수 없을 때 내부 콘텐츠 전체를 교체하는
     * 저수준 이스케이프 해치입니다. 날짜 셀의 접근성·인터랙션 구조는 유지됩니다.
     */
    renderDateCellContent?: (props: DatePickerCellContentRenderProps) => React.ReactNode;
    renderDateCellSupplement?: never;
};
type DatePickerSharedProps = DatePickerBehaviorProps & DatePickerRootProps & {
    /** 날짜 이동과 포커스 action을 받는 ref입니다. */
    actionsRef?: React.Ref<DatePickerActions>;
} & DatePickerCellCustomization;
type ContinuousSizeConstraint = (Required<Pick<StyleProps, "height">> & Pick<StyleProps, "minHeight" | "maxHeight">) | (Required<Pick<StyleProps, "minHeight">> & Pick<StyleProps, "height" | "maxHeight">) | (Required<Pick<StyleProps, "maxHeight">> & Pick<StyleProps, "height" | "minHeight">);
export type DatePickerProps = DatePickerSharedProps;
export type TwoMonthDatePickerProps = DatePickerSharedProps;
export type WeekDatePickerProps = DatePickerSharedProps;
type DatePickerPropsWithoutSize<Props = DatePickerSharedProps> = Props extends DatePickerSharedProps ? Omit<Props, "height" | "minHeight" | "maxHeight"> : never;
export type ContinuousDatePickerProps = DatePickerPropsWithoutSize & ContinuousSizeConstraint;
export declare const DatePicker: React.ForwardRefExoticComponent<DatePickerSharedProps & React.RefAttributes<HTMLDivElement>>;
export declare const TwoMonthDatePicker: React.ForwardRefExoticComponent<DatePickerSharedProps & React.RefAttributes<HTMLDivElement>>;
export declare const WeekDatePicker: React.ForwardRefExoticComponent<DatePickerSharedProps & React.RefAttributes<HTMLDivElement>>;
export declare const ContinuousDatePicker: React.ForwardRefExoticComponent<ContinuousDatePickerProps & React.RefAttributes<HTMLDivElement>>;
export type { DatePickerActions, DatePickerAriaLabels, DatePickerConstraint, DatePickerConstraintContext, DatePickerDate, DatePickerMultipleProps, DatePickerRangeProps, DatePickerRangeValue, DatePickerSelectionMode, DatePickerSingleProps, DatePickerValue, } from '@seed-design/react-date-picker';
//# sourceMappingURL=DatePicker.d.ts.map