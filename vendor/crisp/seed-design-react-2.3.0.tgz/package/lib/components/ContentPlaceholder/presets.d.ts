import { ContentPlaceholderVariant } from '@seed-design/css/recipes/content-placeholder';
export declare const contentPlaceholderAssetPresetMap: Record<ContentPlaceholderVariant["type"], React.ReactNode>;
//# sourceMappingURL=presets.d.ts.map