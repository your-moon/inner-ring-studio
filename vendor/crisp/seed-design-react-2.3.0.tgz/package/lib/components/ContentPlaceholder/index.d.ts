export { ContentPlaceholderRoot, ContentPlaceholderAsset, type ContentPlaceholderRootProps, type ContentPlaceholderAssetProps, } from './ContentPlaceholder';
export * as ContentPlaceholder from './ContentPlaceholder.namespace';
//# sourceMappingURL=index.d.ts.map