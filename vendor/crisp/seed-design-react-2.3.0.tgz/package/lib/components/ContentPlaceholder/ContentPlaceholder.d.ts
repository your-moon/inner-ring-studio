import { ContentPlaceholderVariantProps } from '@seed-design/css/recipes/content-placeholder';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface ContentPlaceholderRootProps extends ContentPlaceholderVariantProps, PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const ContentPlaceholderRoot: React.ForwardRefExoticComponent<ContentPlaceholderRootProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentPlaceholderAssetProps extends React.HTMLAttributes<HTMLElement> {
}
export declare const ContentPlaceholderAsset: React.ForwardRefExoticComponent<ContentPlaceholderAssetProps & React.RefAttributes<HTMLElement>>;
//# sourceMappingURL=ContentPlaceholder.d.ts.map