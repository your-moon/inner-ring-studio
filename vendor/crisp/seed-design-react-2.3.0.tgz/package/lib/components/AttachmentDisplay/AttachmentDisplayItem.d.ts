import { AttachmentInputItemVariantProps } from '@seed-design/css/recipes/attachment-input-item';
import { AttachmentDisplay as AttachmentDisplayPrimitive, DisplayItemEntry } from '@seed-design/react-attachment-display';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface AttachmentDisplayItemProps extends Omit<AttachmentInputItemVariantProps, "type">, PrimitiveProps, React.LiHTMLAttributes<HTMLLIElement> {
    entry: DisplayItemEntry;
}
export declare const AttachmentDisplayItem: React.ForwardRefExoticComponent<AttachmentDisplayItemProps & React.RefAttributes<HTMLLIElement>>;
export interface AttachmentDisplayItemImageProps extends AttachmentDisplayPrimitive.ItemImageProps {
}
export declare const AttachmentDisplayItemImage: React.ForwardRefExoticComponent<AttachmentDisplayItemImageProps & React.RefAttributes<HTMLImageElement>>;
export interface AttachmentDisplayItemThumbnailProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayItemThumbnail: React.ForwardRefExoticComponent<AttachmentDisplayItemThumbnailProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayItemMetadataProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayItemMetadata: React.ForwardRefExoticComponent<AttachmentDisplayItemMetadataProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayItemBackdropProps extends AttachmentDisplayPrimitive.ItemBackdropProps {
}
export declare const AttachmentDisplayItemBackdrop: React.ForwardRefExoticComponent<AttachmentDisplayItemBackdropProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayItemBadgeProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayItemBadge: React.ForwardRefExoticComponent<AttachmentDisplayItemBadgeProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayItemActionButtonProps extends PrimitiveProps, React.ButtonHTMLAttributes<HTMLButtonElement> {
}
export declare const AttachmentDisplayItemActionButton: React.ForwardRefExoticComponent<AttachmentDisplayItemActionButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface AttachmentDisplayItemRemoveButtonProps extends AttachmentDisplayPrimitive.ItemRemoveButtonProps {
}
export declare const AttachmentDisplayItemRemoveButton: React.ForwardRefExoticComponent<AttachmentDisplayItemRemoveButtonProps & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=AttachmentDisplayItem.d.ts.map