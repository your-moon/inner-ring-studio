import { AttachmentInputTriggerVariantProps } from '@seed-design/css/recipes/attachment-input-trigger';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface AttachmentDisplayTriggerProps extends AttachmentInputTriggerVariantProps, PrimitiveProps, React.ButtonHTMLAttributes<HTMLButtonElement> {
}
export declare const AttachmentDisplayTrigger: React.ForwardRefExoticComponent<AttachmentDisplayTriggerProps & React.RefAttributes<HTMLButtonElement>>;
type DisplayAcceptType = "image";
export type AttachmentDisplayTriggerIconProps = React.SVGAttributes<SVGElement> & {
    [K in DisplayAcceptType]: React.ReactNode;
};
export declare const AttachmentDisplayTriggerIcon: React.ForwardRefExoticComponent<React.SVGAttributes<SVGElement> & {
    image: React.ReactNode;
} & React.RefAttributes<SVGSVGElement>>;
export interface AttachmentDisplayTriggerItemCountProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayTriggerItemCount: React.ForwardRefExoticComponent<AttachmentDisplayTriggerItemCountProps & React.RefAttributes<HTMLDivElement>>;
export {};
//# sourceMappingURL=AttachmentDisplayTrigger.d.ts.map