import { AttachmentInputVariantProps } from '@seed-design/css/recipes/attachment-input';
import { FieldVariantProps } from '@seed-design/css/recipes/field';
import { FieldLabelVariantProps } from '@seed-design/css/recipes/field-label';
import { AttachmentDisplay as AttachmentDisplayPrimitive } from '@seed-design/react-attachment-display';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface AttachmentDisplayRootProps extends FieldVariantProps, AttachmentDisplayPrimitive.RootProps {
}
export declare const AttachmentDisplayRoot: React.ForwardRefExoticComponent<AttachmentDisplayRootProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayHeaderProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayHeader: React.ForwardRefExoticComponent<AttachmentDisplayHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayLabelProps extends PrimitiveProps, FieldLabelVariantProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayLabel: React.ForwardRefExoticComponent<AttachmentDisplayLabelProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayIndicatorTextProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const AttachmentDisplayIndicatorText: React.ForwardRefExoticComponent<AttachmentDisplayIndicatorTextProps & React.RefAttributes<HTMLSpanElement>>;
export interface AttachmentDisplayRequiredIndicatorProps extends React.SVGProps<SVGElement> {
}
export declare const AttachmentDisplayRequiredIndicator: React.ForwardRefExoticComponent<Omit<AttachmentDisplayRequiredIndicatorProps, "ref"> & React.RefAttributes<SVGSVGElement>>;
export interface AttachmentDisplayControlProps extends AttachmentInputVariantProps, PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayControl: React.ForwardRefExoticComponent<AttachmentDisplayControlProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayContainerProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayContainer: React.ForwardRefExoticComponent<AttachmentDisplayContainerProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayItemGroupProps extends PrimitiveProps, React.HTMLAttributes<HTMLUListElement> {
}
export declare const AttachmentDisplayItemGroup: React.ForwardRefExoticComponent<AttachmentDisplayItemGroupProps & React.RefAttributes<HTMLUListElement>>;
export interface AttachmentDisplayFooterProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentDisplayFooter: React.ForwardRefExoticComponent<AttachmentDisplayFooterProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentDisplayDescriptionProps extends AttachmentDisplayPrimitive.DescriptionProps {
}
export declare const AttachmentDisplayDescription: React.ForwardRefExoticComponent<AttachmentDisplayDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
export interface AttachmentDisplayErrorMessageProps extends AttachmentDisplayPrimitive.ErrorMessageProps {
}
export declare const AttachmentDisplayErrorMessage: React.ForwardRefExoticComponent<AttachmentDisplayErrorMessageProps & React.RefAttributes<HTMLSpanElement>>;
export interface AttachmentDisplayContextProps extends AttachmentDisplayPrimitive.ContextProps {
}
export declare const AttachmentDisplayContext: (props: AttachmentDisplayPrimitive.ContextProps) => React.ReactNode;
//# sourceMappingURL=AttachmentDisplay.d.ts.map