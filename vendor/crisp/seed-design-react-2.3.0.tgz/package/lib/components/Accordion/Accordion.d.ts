import { AccordionVariantProps } from '@seed-design/css/recipes/accordion';
import { Accordion as AccordionPrimitive } from '@seed-design/react-accordion';
import { PrimitiveProps } from '@seed-design/react-primitive';
import type * as React from "react";
export interface AccordionRootProps extends AccordionVariantProps, AccordionPrimitive.RootProps {
}
export declare const AccordionRoot: React.ForwardRefExoticComponent<AccordionRootProps & React.RefAttributes<HTMLDivElement>>;
export interface AccordionItemProps extends AccordionPrimitive.ItemProps {
}
export declare const AccordionItem: React.ForwardRefExoticComponent<AccordionItemProps & React.RefAttributes<HTMLDivElement>>;
export interface AccordionHeaderProps extends AccordionPrimitive.HeaderProps {
}
export declare const AccordionHeader: React.ForwardRefExoticComponent<AccordionHeaderProps & React.RefAttributes<HTMLHeadingElement>>;
export interface AccordionTriggerProps extends AccordionPrimitive.TriggerProps {
}
export declare const AccordionTrigger: React.ForwardRefExoticComponent<AccordionTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface AccordionContentProps extends AccordionPrimitive.ContentProps {
}
export declare const AccordionContent: React.ForwardRefExoticComponent<AccordionContentProps & React.RefAttributes<HTMLDivElement>>;
export interface AccordionBodyProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AccordionBody: React.ForwardRefExoticComponent<AccordionBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface AccordionTitleProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const AccordionTitle: React.ForwardRefExoticComponent<AccordionTitleProps & React.RefAttributes<HTMLSpanElement>>;
export interface AccordionDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const AccordionDescription: React.ForwardRefExoticComponent<AccordionDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
export interface AccordionPrefixProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AccordionPrefix: React.ForwardRefExoticComponent<AccordionPrefixProps & React.RefAttributes<HTMLDivElement>>;
export interface AccordionSuffixIconProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AccordionSuffixIcon: React.ForwardRefExoticComponent<AccordionSuffixIconProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Accordion.d.ts.map