import { BreakpointThreshold } from '../../types/responsive';
import { StyleProps } from '../../utils/styled';
import * as React from "react";
export type BoxProps = StyleProps & Omit<React.HTMLAttributes<HTMLDivElement>, "color"> & {
    as?: React.ElementType;
    asChild?: boolean;
    hideFrom?: BreakpointThreshold;
};
export declare const Box: React.ForwardRefExoticComponent<BoxProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Box.d.ts.map