import { AttachmentInputVariantProps, AttachmentInputSlotName } from '@seed-design/css/recipes/attachment-input';
import { FileUpload as FileUploadPrimitive } from '@seed-design/react-file-upload';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export declare const withProvider: <T, P>(Component: React.ElementType<any>, slot: AttachmentInputSlotName, options?: {
    defaultProps?: Partial<P> | undefined;
} | undefined) => React.ForwardRefExoticComponent<React.PropsWithoutRef<P> & React.RefAttributes<T>>, withContext: <T, P>(Component: React.ElementType<any>, slot?: AttachmentInputSlotName | undefined) => React.ForwardRefExoticComponent<React.PropsWithoutRef<P> & React.RefAttributes<T>>;
export interface AttachmentInputRootProps extends AttachmentInputVariantProps, FileUploadPrimitive.RootProps {
}
export declare const AttachmentInputRoot: React.ForwardRefExoticComponent<AttachmentInputRootProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentInputContainerProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputContainer: React.ForwardRefExoticComponent<AttachmentInputContainerProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentInputHiddenInputProps extends FileUploadPrimitive.HiddenInputProps {
}
export declare const AttachmentInputHiddenInput: React.ForwardRefExoticComponent<AttachmentInputHiddenInputProps & React.RefAttributes<HTMLInputElement>>;
export interface AttachmentInputItemGroupProps extends PrimitiveProps, React.HTMLAttributes<HTMLUListElement> {
}
export declare const AttachmentInputItemGroup: React.ForwardRefExoticComponent<AttachmentInputItemGroupProps & React.RefAttributes<HTMLUListElement>>;
export interface AttachmentInputContextProps extends FileUploadPrimitive.ContextProps {
}
export declare const AttachmentInputContext: (props: FileUploadPrimitive.ContextProps) => React.ReactNode;
//# sourceMappingURL=AttachmentInput.d.ts.map