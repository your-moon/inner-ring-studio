import { AttachmentInputTriggerVariantProps } from '@seed-design/css/recipes/attachment-input-trigger';
import { FileAcceptType } from '@seed-design/react-file-upload';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface AttachmentInputTriggerProps extends AttachmentInputTriggerVariantProps, PrimitiveProps, React.ButtonHTMLAttributes<HTMLButtonElement> {
}
export declare const AttachmentInputTrigger: React.ForwardRefExoticComponent<AttachmentInputTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export type AttachmentInputTriggerIconProps = React.SVGAttributes<SVGElement> & {
    [K in NonNullable<FileAcceptType>]?: React.ReactNode;
} & {
    general: React.ReactNode;
};
export declare const AttachmentInputTriggerIcon: React.ForwardRefExoticComponent<React.SVGAttributes<SVGElement> & {
    image?: React.ReactNode;
} & {
    general: React.ReactNode;
} & React.RefAttributes<SVGSVGElement>>;
export interface AttachmentInputTriggerItemCountProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputTriggerItemCount: React.ForwardRefExoticComponent<AttachmentInputTriggerItemCountProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=AttachmentInputTrigger.d.ts.map