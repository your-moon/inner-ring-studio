export {};
//# sourceMappingURL=AttachmentInput.test.d.ts.map