import { AttachmentInputItemVariantProps } from '@seed-design/css/recipes/attachment-input-item';
import { FileUpload as FileUploadPrimitive, FileEntry } from '@seed-design/react-file-upload';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface AttachmentInputItemProps extends AttachmentInputItemVariantProps, PrimitiveProps, React.LiHTMLAttributes<HTMLLIElement> {
    fileEntry: FileEntry;
}
export declare const AttachmentInputItem: React.ForwardRefExoticComponent<AttachmentInputItemProps & React.RefAttributes<HTMLLIElement>>;
export interface AttachmentInputItemNameProps extends PrimitiveProps, FileUploadPrimitive.ItemNameProps {
}
export declare const AttachmentInputItemName: React.ForwardRefExoticComponent<AttachmentInputItemNameProps & React.RefAttributes<HTMLSpanElement>>;
export interface AttachmentInputItemSizeProps extends FileUploadPrimitive.ItemSizeProps {
}
export declare const AttachmentInputItemSize: React.ForwardRefExoticComponent<AttachmentInputItemSizeProps & React.RefAttributes<HTMLSpanElement>>;
export interface AttachmentInputItemRemoveButtonProps extends FileUploadPrimitive.ItemRemoveButtonProps {
}
export declare const AttachmentInputItemRemoveButton: React.ForwardRefExoticComponent<AttachmentInputItemRemoveButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface AttachmentInputItemImageProps extends FileUploadPrimitive.ItemImageProps {
}
export declare const AttachmentInputItemImage: React.ForwardRefExoticComponent<AttachmentInputItemImageProps & React.RefAttributes<HTMLImageElement>>;
export interface AttachmentInputItemThumbnailProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputItemThumbnail: React.ForwardRefExoticComponent<AttachmentInputItemThumbnailProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentInputItemBadgeProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputItemBadge: React.ForwardRefExoticComponent<AttachmentInputItemBadgeProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentInputItemActionButtonProps extends PrimitiveProps, React.ButtonHTMLAttributes<HTMLButtonElement> {
}
export declare const AttachmentInputItemActionButton: React.ForwardRefExoticComponent<AttachmentInputItemActionButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface AttachmentInputItemBackdropProps extends FileUploadPrimitive.ItemBackdropProps {
}
export declare const AttachmentInputItemBackdrop: React.ForwardRefExoticComponent<AttachmentInputItemBackdropProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentInputItemMetadataProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputItemMetadata: React.ForwardRefExoticComponent<AttachmentInputItemMetadataProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=AttachmentInputItem.d.ts.map