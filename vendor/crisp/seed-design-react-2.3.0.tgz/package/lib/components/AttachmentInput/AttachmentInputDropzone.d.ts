import { PrimitiveProps } from '@seed-design/react-primitive';
import type * as React from "react";
export interface AttachmentInputDropzoneProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputDropzone: React.ForwardRefExoticComponent<AttachmentInputDropzoneProps & React.RefAttributes<HTMLDivElement>>;
export interface AttachmentInputDropzoneLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const AttachmentInputDropzoneLabel: React.ForwardRefExoticComponent<AttachmentInputDropzoneLabelProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=AttachmentInputDropzone.d.ts.map