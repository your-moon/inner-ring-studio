import { DistributiveOmit } from '../../utils/styled';
import { FlexProps } from '../Flex';
import * as React from "react";
/**
 * @deprecated Use `VStack` instead.
 */
export type StackProps = DistributiveOmit<FlexProps, "flexDirection">;
/**
 * @deprecated Use `VStack` instead.
 */
export declare const Stack: React.ForwardRefExoticComponent<StackProps & React.RefAttributes<HTMLDivElement>>;
export type VStackProps = DistributiveOmit<FlexProps, "flexDirection">;
export declare const VStack: React.ForwardRefExoticComponent<VStackProps & React.RefAttributes<HTMLDivElement>>;
export type HStackProps = DistributiveOmit<FlexProps, "flexDirection">;
export declare const HStack: React.ForwardRefExoticComponent<HStackProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Stack.d.ts.map