import { Dialog as DialogPrimitive } from '@seed-design/react-dialog';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { MenuSheetVariantProps } from '@seed-design/css/recipes/menu-sheet';
import { MenuSheetItemVariantProps } from '@seed-design/css/recipes/menu-sheet-item';
import * as React from "react";
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetRootProps extends MenuSheetVariantProps, DialogPrimitive.RootProps {
    /**
     * @default true
     */
    lazyMount?: DialogPrimitive.RootProps["lazyMount"];
    /**
     * @default true
     */
    unmountOnExit?: DialogPrimitive.RootProps["unmountOnExit"];
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetRoot: React.ForwardRefExoticComponent<MenuSheetRootProps>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetTriggerProps extends DialogPrimitive.TriggerProps {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetTrigger: React.ForwardRefExoticComponent<DialogPrimitive.TriggerProps & React.RefAttributes<HTMLButtonElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetPositionerProps extends DialogPrimitive.PositionerProps {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetPositioner: React.ForwardRefExoticComponent<MenuSheetPositionerProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetBackdropProps extends DialogPrimitive.BackdropProps {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetBackdrop: React.ForwardRefExoticComponent<MenuSheetBackdropProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetContentProps extends DialogPrimitive.ContentProps, Pick<MenuSheetItemVariantProps, "labelAlign"> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetContent: React.ForwardRefExoticComponent<MenuSheetContentProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetHeaderProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetHeader: React.ForwardRefExoticComponent<MenuSheetHeaderProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetTitleProps extends DialogPrimitive.TitleProps {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetTitle: React.ForwardRefExoticComponent<MenuSheetTitleProps & React.RefAttributes<HTMLHeadingElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetDescriptionProps extends DialogPrimitive.DescriptionProps {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetDescription: React.ForwardRefExoticComponent<MenuSheetDescriptionProps & React.RefAttributes<HTMLParagraphElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetListProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetList: React.ForwardRefExoticComponent<MenuSheetListProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetGroupProps extends React.HTMLAttributes<HTMLDivElement>, Pick<MenuSheetItemVariantProps, "labelAlign"> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetGroup: React.ForwardRefExoticComponent<MenuSheetGroupProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetItemProps extends PrimitiveProps, MenuSheetItemVariantProps, React.HTMLAttributes<HTMLButtonElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetItem: React.ForwardRefExoticComponent<MenuSheetItemProps & React.RefAttributes<HTMLButtonElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetItemContentProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetItemContent: React.ForwardRefExoticComponent<MenuSheetItemContentProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetItemLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetItemLabel: React.ForwardRefExoticComponent<MenuSheetItemLabelProps & React.RefAttributes<HTMLSpanElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetItemDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetItemDescription: React.ForwardRefExoticComponent<MenuSheetItemDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetFooterProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetFooter: React.ForwardRefExoticComponent<MenuSheetFooterProps & React.RefAttributes<HTMLDivElement>>;
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export interface MenuSheetCloseButtonProps extends DialogPrimitive.CloseButtonProps {
}
/**
 * @deprecated Use `SwipeableMenuSheet` instead.
 */
export declare const MenuSheetCloseButton: React.ForwardRefExoticComponent<MenuSheetCloseButtonProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=MenuSheet.d.ts.map