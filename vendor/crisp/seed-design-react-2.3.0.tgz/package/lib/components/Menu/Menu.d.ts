import { Menu as MenuPrimitive } from '@seed-design/react-menu';
import { MenuVariantProps } from '@seed-design/css/recipes/menu';
import { MenuItemVariantProps } from '@seed-design/css/recipes/menu-item';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface MenuRootProps extends MenuVariantProps, MenuPrimitive.RootProps {
}
export declare const MenuRoot: (props: MenuRootProps) => import("react/jsx-runtime").JSX.Element;
export interface MenuAnchorProps extends MenuPrimitive.AnchorProps {
}
export declare const MenuAnchor: React.ForwardRefExoticComponent<MenuPrimitive.AnchorProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuTriggerProps extends MenuPrimitive.TriggerProps {
}
export declare const MenuTrigger: React.ForwardRefExoticComponent<MenuPrimitive.TriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface MenuPositionerProps extends MenuPrimitive.PositionerProps, PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const MenuPositioner: React.ForwardRefExoticComponent<MenuPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuContentProps extends MenuPrimitive.ContentProps {
}
export declare const MenuContent: React.ForwardRefExoticComponent<MenuContentProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuScrollAreaProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const MenuScrollArea: React.ForwardRefExoticComponent<MenuScrollAreaProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuGroupProps extends MenuPrimitive.GroupProps {
}
export declare const MenuGroup: React.ForwardRefExoticComponent<MenuGroupProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuGroupLabelProps extends MenuPrimitive.GroupLabelProps {
}
export declare const MenuGroupLabel: React.ForwardRefExoticComponent<MenuGroupLabelProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuItemProps extends MenuItemVariantProps, MenuPrimitive.ItemProps {
}
export declare const MenuItem: React.ForwardRefExoticComponent<MenuItemProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuItemBodyProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const MenuItemBody: React.ForwardRefExoticComponent<MenuItemBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface MenuItemLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const MenuItemLabel: React.ForwardRefExoticComponent<MenuItemLabelProps & React.RefAttributes<HTMLSpanElement>>;
export interface MenuItemDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const MenuItemDescription: React.ForwardRefExoticComponent<MenuItemDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
//# sourceMappingURL=Menu.d.ts.map