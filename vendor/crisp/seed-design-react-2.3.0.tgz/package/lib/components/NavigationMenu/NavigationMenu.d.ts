import { MenuVariantProps } from '@seed-design/css/recipes/menu';
import { MenuItemVariantProps } from '@seed-design/css/recipes/menu-item';
import { NavigationMenu as NavigationMenuPrimitive } from '@seed-design/react-navigation-menu';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface NavigationMenuProviderProps extends MenuVariantProps, NavigationMenuPrimitive.ProviderProps {
}
export declare const NavigationMenuProvider: (props: NavigationMenuProviderProps) => import("react/jsx-runtime").JSX.Element;
export interface NavigationMenuRootProps extends NavigationMenuPrimitive.RootProps {
}
export declare const NavigationMenuRoot: ({ value, disabled, placement, gutter, overflowPadding, strategy, children, }: NavigationMenuPrimitive.RootProps) => import("react/jsx-runtime").JSX.Element;
export interface NavigationMenuTriggerProps extends NavigationMenuPrimitive.TriggerProps {
}
export declare const NavigationMenuTrigger: React.ForwardRefExoticComponent<NavigationMenuPrimitive.TriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface NavigationMenuPositionerProps extends NavigationMenuPrimitive.PositionerProps {
}
export declare const NavigationMenuPositioner: React.ForwardRefExoticComponent<NavigationMenuPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface NavigationMenuContentProps extends NavigationMenuPrimitive.ContentProps {
}
export declare const NavigationMenuContent: React.ForwardRefExoticComponent<NavigationMenuContentProps & React.RefAttributes<HTMLDivElement>>;
export interface NavigationMenuScrollAreaProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const NavigationMenuScrollArea: React.ForwardRefExoticComponent<NavigationMenuScrollAreaProps & React.RefAttributes<HTMLDivElement>>;
export interface NavigationMenuGroupProps extends NavigationMenuPrimitive.GroupProps {
}
export declare const NavigationMenuGroup: React.ForwardRefExoticComponent<NavigationMenuGroupProps & React.RefAttributes<HTMLDivElement>>;
export interface NavigationMenuGroupLabelProps extends NavigationMenuPrimitive.GroupLabelProps {
}
export declare const NavigationMenuGroupLabel: React.ForwardRefExoticComponent<NavigationMenuGroupLabelProps & React.RefAttributes<HTMLDivElement>>;
export interface NavigationMenuItemProps extends MenuItemVariantProps, NavigationMenuPrimitive.ItemProps {
}
export declare const NavigationMenuItem: React.ForwardRefExoticComponent<NavigationMenuItemProps & React.RefAttributes<HTMLButtonElement>>;
export interface NavigationMenuItemBodyProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const NavigationMenuItemBody: React.ForwardRefExoticComponent<NavigationMenuItemBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface NavigationMenuItemLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const NavigationMenuItemLabel: React.ForwardRefExoticComponent<NavigationMenuItemLabelProps & React.RefAttributes<HTMLSpanElement>>;
export interface NavigationMenuItemDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const NavigationMenuItemDescription: React.ForwardRefExoticComponent<NavigationMenuItemDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
//# sourceMappingURL=NavigationMenu.d.ts.map