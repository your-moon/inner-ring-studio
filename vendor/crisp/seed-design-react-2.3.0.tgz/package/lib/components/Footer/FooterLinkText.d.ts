import { FooterVariantProps } from '@seed-design/css/recipes/footer';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface FooterLinkTextProps extends FooterVariantProps, PrimitiveProps, React.AnchorHTMLAttributes<HTMLAnchorElement> {
}
export declare const FooterLinkText: React.ForwardRefExoticComponent<FooterLinkTextProps & React.RefAttributes<HTMLAnchorElement>>;
//# sourceMappingURL=FooterLinkText.d.ts.map