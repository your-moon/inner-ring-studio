export { FooterLinkText as LinkText, type FooterLinkTextProps as LinkTextProps, } from './FooterLinkText';
//# sourceMappingURL=Footer.namespace.d.ts.map