export { FooterLinkText, type FooterLinkTextProps } from './FooterLinkText';
export * as Footer from './Footer.namespace';
//# sourceMappingURL=index.d.ts.map