import { Breakpoint } from '@seed-design/css/breakpoints';
import { BottomSheet } from '../BottomSheet';
import { SidePanel } from '../SidePanel';
import * as React from "react";
type SharedProps<SidePanelProps, BottomSheetProps> = Pick<SidePanelProps, Extract<keyof SidePanelProps, keyof BottomSheetProps>> & Pick<BottomSheetProps, Extract<keyof BottomSheetProps, keyof SidePanelProps>>;
interface ResponsiveSidePanelContextValue {
    shouldUseBottomSheet: boolean | undefined;
}
export declare function useResponsiveSidePanelContext(): ResponsiveSidePanelContextValue;
export interface ResponsiveSidePanelRootProps {
    children?: React.ReactNode;
    open?: boolean;
    defaultOpen?: boolean;
    onOpenChange?: (open: boolean) => void;
    /**
     * Breakpoint at and above which the panel renders as a SidePanel; below it, a
     * BottomSheet. Cannot be `"base"`, which would always be a SidePanel.
     * @default "md"
     */
    sidePanelBreakpoint?: Exclude<Breakpoint, "base">;
    /** Props forwarded to the underlying SidePanel root (at and above the breakpoint). */
    sidePanelRootProps?: Omit<SidePanel.RootProps, "children" | "open" | "defaultOpen" | "onOpenChange">;
    /** Props forwarded to the underlying BottomSheet root (below the breakpoint). */
    bottomSheetRootProps?: Omit<BottomSheet.RootProps, "children" | "open" | "defaultOpen" | "onOpenChange">;
}
export declare const ResponsiveSidePanelRoot: ({ children, open: openProp, defaultOpen, onOpenChange, sidePanelBreakpoint, sidePanelRootProps, bottomSheetRootProps, }: ResponsiveSidePanelRootProps) => import("react/jsx-runtime").JSX.Element;
export interface ResponsiveSidePanelTriggerProps extends SharedProps<SidePanel.TriggerProps, BottomSheet.TriggerProps> {
}
export declare const ResponsiveSidePanelTrigger: React.ForwardRefExoticComponent<ResponsiveSidePanelTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface ResponsiveSidePanelPositionerProps extends SharedProps<SidePanel.PositionerProps, BottomSheet.PositionerProps> {
}
export declare const ResponsiveSidePanelPositioner: React.ForwardRefExoticComponent<ResponsiveSidePanelPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveSidePanelBackdropProps extends SharedProps<SidePanel.BackdropProps, BottomSheet.BackdropProps> {
}
export declare const ResponsiveSidePanelBackdrop: React.ForwardRefExoticComponent<ResponsiveSidePanelBackdropProps & React.RefAttributes<HTMLDivElement>>;
/**
 * `width` / `maxWidth` only apply in SidePanel mode (md+); they are ignored when
 * rendered as a BottomSheet.
 */
export interface ResponsiveSidePanelContentProps extends SharedProps<SidePanel.ContentProps, BottomSheet.ContentProps>, Pick<SidePanel.ContentProps, "width" | "maxWidth"> {
}
export declare const ResponsiveSidePanelContent: React.ForwardRefExoticComponent<ResponsiveSidePanelContentProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveSidePanelHeaderProps extends SharedProps<SidePanel.HeaderProps, BottomSheet.HeaderProps> {
}
export declare const ResponsiveSidePanelHeader: React.ForwardRefExoticComponent<ResponsiveSidePanelHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveSidePanelTitleProps extends SharedProps<SidePanel.TitleProps, BottomSheet.TitleProps> {
}
export declare const ResponsiveSidePanelTitle: React.ForwardRefExoticComponent<ResponsiveSidePanelTitleProps & React.RefAttributes<HTMLHeadingElement>>;
export interface ResponsiveSidePanelDescriptionProps extends SharedProps<SidePanel.DescriptionProps, BottomSheet.DescriptionProps> {
}
export declare const ResponsiveSidePanelDescription: React.ForwardRefExoticComponent<ResponsiveSidePanelDescriptionProps & React.RefAttributes<HTMLParagraphElement>>;
export interface ResponsiveSidePanelBodyProps extends SharedProps<SidePanel.BodyProps, BottomSheet.BodyProps> {
}
export declare const ResponsiveSidePanelBody: React.ForwardRefExoticComponent<ResponsiveSidePanelBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveSidePanelFooterProps extends SharedProps<SidePanel.FooterProps, BottomSheet.FooterProps> {
}
export declare const ResponsiveSidePanelFooter: React.ForwardRefExoticComponent<ResponsiveSidePanelFooterProps & React.RefAttributes<HTMLDivElement>>;
export interface ResponsiveSidePanelCloseButtonProps extends SharedProps<SidePanel.CloseButtonProps, BottomSheet.CloseButtonProps> {
}
export declare const ResponsiveSidePanelCloseButton: React.ForwardRefExoticComponent<ResponsiveSidePanelCloseButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface ResponsiveSidePanelHandleProps extends BottomSheet.HandleProps {
}
export declare const ResponsiveSidePanelHandle: React.ForwardRefExoticComponent<ResponsiveSidePanelHandleProps & React.RefAttributes<HTMLDivElement>>;
export {};
//# sourceMappingURL=ResponsiveSidePanel.d.ts.map