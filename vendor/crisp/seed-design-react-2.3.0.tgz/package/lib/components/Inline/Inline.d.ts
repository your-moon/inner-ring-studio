import { DistributiveOmit } from '../../utils/styled';
import { BoxProps } from '../Box/Box';
import * as React from "react";
/**
 * @deprecated Use `HStack` instead.
 */
export type InlineProps = DistributiveOmit<BoxProps, "display" | "direction" | "flexWrap">;
/**
 * @deprecated Use `HStack` instead.
 */
export declare const Inline: React.ForwardRefExoticComponent<InlineProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Inline.d.ts.map