import { ContentDialogVariantProps } from '@seed-design/css/recipes/content-dialog';
import { Dialog as DialogPrimitive } from '@seed-design/react-dialog';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { StyleProps } from '../../utils/styled';
import * as React from "react";
export interface ContentDialogRootProps extends ContentDialogVariantProps, Omit<DialogPrimitive.RootProps, "role"> {
    /**
     * @default true
     */
    lazyMount?: DialogPrimitive.RootProps["lazyMount"];
    /**
     * @default true
     */
    unmountOnExit?: DialogPrimitive.RootProps["unmountOnExit"];
}
export declare function ContentDialogRoot(props: ContentDialogRootProps): import("react/jsx-runtime").JSX.Element;
export interface ContentDialogTriggerProps extends DialogPrimitive.TriggerProps {
}
export declare const ContentDialogTrigger: React.ForwardRefExoticComponent<DialogPrimitive.TriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface ContentDialogPositionerProps extends DialogPrimitive.PositionerProps {
}
export declare const ContentDialogPositioner: React.ForwardRefExoticComponent<ContentDialogPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentDialogBackdropProps extends DialogPrimitive.BackdropProps {
}
export declare const ContentDialogBackdrop: React.ForwardRefExoticComponent<ContentDialogBackdropProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentDialogContentProps extends DialogPrimitive.ContentProps, Pick<StyleProps, "width" | "maxWidth"> {
}
export declare const ContentDialogContent: React.ForwardRefExoticComponent<ContentDialogContentProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentDialogHeaderProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const ContentDialogHeader: React.ForwardRefExoticComponent<ContentDialogHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentDialogTitleProps extends DialogPrimitive.TitleProps {
}
export declare const ContentDialogTitle: React.ForwardRefExoticComponent<ContentDialogTitleProps & React.RefAttributes<HTMLHeadingElement>>;
export interface ContentDialogDescriptionProps extends DialogPrimitive.DescriptionProps {
}
export declare const ContentDialogDescription: React.ForwardRefExoticComponent<ContentDialogDescriptionProps & React.RefAttributes<HTMLParagraphElement>>;
export interface ContentDialogBodyProps extends PrimitiveProps, Pick<StyleProps, "paddingX" | "minHeight" | "maxHeight" | "justifyContent" | "alignItems">, React.HTMLAttributes<HTMLDivElement> {
}
export declare const ContentDialogBody: React.ForwardRefExoticComponent<ContentDialogBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentDialogFooterProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const ContentDialogFooter: React.ForwardRefExoticComponent<ContentDialogFooterProps & React.RefAttributes<HTMLDivElement>>;
export interface ContentDialogActionProps extends DialogPrimitive.CloseButtonProps {
}
export declare const ContentDialogAction: React.ForwardRefExoticComponent<DialogPrimitive.CloseButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface ContentDialogCloseButtonProps extends DialogPrimitive.CloseButtonProps {
}
export declare const ContentDialogCloseButton: React.ForwardRefExoticComponent<ContentDialogCloseButtonProps & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=ContentDialog.d.ts.map