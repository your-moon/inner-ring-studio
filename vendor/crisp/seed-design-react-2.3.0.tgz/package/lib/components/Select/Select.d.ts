import { Select as SelectPrimitive } from '@seed-design/react-select';
import { SelectVariantProps } from '@seed-design/css/recipes/select';
import { SelectTriggerVariantProps } from '@seed-design/css/recipes/select-trigger';
import { SelectItemVariantProps } from '@seed-design/css/recipes/select-item';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { InternalIconProps } from '../private/Icon';
import * as React from "react";
export interface SelectRootProps extends SelectVariantProps, SelectTriggerVariantProps, SelectItemVariantProps, SelectPrimitive.RootProps {
}
export declare const SelectRoot: (props: SelectRootProps) => import("react/jsx-runtime").JSX.Element;
export interface SelectTriggerProps extends SelectTriggerVariantProps, SelectPrimitive.TriggerProps {
}
export declare const SelectTrigger: React.ForwardRefExoticComponent<SelectTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface SelectValueProps extends SelectPrimitive.ValueProps {
}
export declare const SelectValue: React.ForwardRefExoticComponent<SelectValueProps & React.RefAttributes<HTMLSpanElement>>;
export interface SelectPlaceholderProps extends SelectPrimitive.PlaceholderProps {
}
export declare const SelectPlaceholder: React.ForwardRefExoticComponent<SelectPlaceholderProps & React.RefAttributes<HTMLSpanElement>>;
export interface SelectPrefixIconProps extends React.SVGAttributes<SVGSVGElement> {
    /**
     * The fallback icon shown when the current selection supplies no icon of its
     * own. While exactly one item is selected, that item's `icon` takes over the
     * slot; this fallback shows when that item has no icon — and for empty or
     * multi selections. Named `fallback` (not `svg`) because a selected item's own
     * icon outranks it, so what you pass here may not be what renders.
     */
    fallback?: React.ReactNode;
}
export declare const SelectPrefixIcon: React.ForwardRefExoticComponent<SelectPrefixIconProps & React.RefAttributes<SVGSVGElement>>;
export interface SelectSuffixIconProps extends InternalIconProps {
}
export declare const SelectSuffixIcon: React.ForwardRefExoticComponent<SelectSuffixIconProps & React.RefAttributes<SVGSVGElement>>;
export interface SelectPositionerProps extends SelectPrimitive.PositionerProps {
}
export declare const SelectPositioner: React.ForwardRefExoticComponent<SelectPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectContentProps extends SelectPrimitive.ContentProps {
}
export declare const SelectContent: React.ForwardRefExoticComponent<SelectContentProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectScrollAreaProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SelectScrollArea: React.ForwardRefExoticComponent<SelectScrollAreaProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectGroupProps extends SelectPrimitive.GroupProps {
}
export declare const SelectGroup: React.ForwardRefExoticComponent<SelectGroupProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectGroupLabelProps extends SelectPrimitive.GroupLabelProps {
}
export declare const SelectGroupLabel: React.ForwardRefExoticComponent<SelectGroupLabelProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectItemProps extends SelectItemVariantProps, Omit<SelectPrimitive.ItemProps, "icon"> {
    /**
     * The option's prefix icon. Forwarded to the headless item's position-agnostic
     * `icon`, which registers it for the trigger prefix slot and exposes it to the
     * styled `ItemPrefixIcon` rendered in the row.
     */
    prefixIcon?: React.ReactNode;
}
export declare const SelectItem: React.ForwardRefExoticComponent<SelectItemProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectItemPrefixIconProps extends React.SVGAttributes<SVGSVGElement> {
    /**
     * Overrides the icon to render. Defaults to the item's own `icon` (read
     * from item context), so the row shows the icon the item registered.
     */
    svg?: React.ReactNode;
}
export declare const SelectItemPrefixIcon: React.ForwardRefExoticComponent<SelectItemPrefixIconProps & React.RefAttributes<SVGSVGElement>>;
export interface SelectItemBodyProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SelectItemBody: React.ForwardRefExoticComponent<SelectItemBodyProps & React.RefAttributes<HTMLDivElement>>;
export interface SelectItemLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const SelectItemLabel: React.ForwardRefExoticComponent<SelectItemLabelProps & React.RefAttributes<HTMLSpanElement>>;
export interface SelectItemDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const SelectItemDescription: React.ForwardRefExoticComponent<SelectItemDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
export interface SelectItemIndicatorProps extends React.SVGAttributes<SVGSVGElement> {
    /**
     * The icon to display when the item is selected.
     */
    selected: React.ReactNode;
    /**
     * The icon to display when the item is not selected.
     */
    unselected?: React.ReactNode;
}
export declare const SelectItemIndicator: React.ForwardRefExoticComponent<SelectItemIndicatorProps & React.RefAttributes<SVGSVGElement>>;
export interface SelectHiddenSelectProps extends SelectPrimitive.HiddenSelectProps {
}
export declare const SelectHiddenSelect: React.ForwardRefExoticComponent<SelectHiddenSelectProps & React.RefAttributes<HTMLSelectElement>>;
//# sourceMappingURL=Select.d.ts.map