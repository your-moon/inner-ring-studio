import { ScrollFogProps } from '../ScrollFog/ScrollFog';
import * as HeadlessWheelPicker from "@seed-design/react-wheel-picker";
import * as React from "react";
export interface InternalWheelPickerRootProps extends Omit<HeadlessWheelPicker.WheelPickerRootProps, "asChild" | "children"> {
    children: React.ReactNode;
    columnsClassName?: string;
    scrollFogClassName?: string;
    selectionIndicatorClassName?: string;
    fogSize?: ScrollFogProps["size"];
}
export declare const InternalWheelPickerRoot: React.ForwardRefExoticComponent<InternalWheelPickerRootProps & React.RefAttributes<HTMLDivElement>>;
export interface InternalWheelPickerColumnProps extends Omit<HeadlessWheelPicker.WheelPickerColumnProps, "asChild" | "renderOption"> {
    itemClassName?: string;
}
export declare const InternalWheelPickerColumn: React.ForwardRefExoticComponent<InternalWheelPickerColumnProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=WheelPicker.d.ts.map