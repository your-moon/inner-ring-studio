import { BoxProps } from '../Box/Box';
import * as React from "react";
export type ArticleProps = BoxProps;
export declare const Article: React.ForwardRefExoticComponent<BoxProps & React.RefAttributes<HTMLElement>>;
//# sourceMappingURL=Article.d.ts.map