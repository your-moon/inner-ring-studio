import { Tooltip as TooltipPrimitive } from '@seed-design/react-tooltip';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { HelpBubbleVariantProps } from '@seed-design/css/recipes/help-bubble';
import { StyleProps } from '../../utils/styled';
import { ForwardRefExoticComponent, RefAttributes } from 'react';
export interface HelpBubbleTooltipRootProps extends HelpBubbleVariantProps, TooltipPrimitive.RootProps {
    /**
     * @default "top"
     */
    placement?: TooltipPrimitive.RootProps["placement"];
    /**
     * @default 4
     */
    gutter?: TooltipPrimitive.RootProps["gutter"];
    /**
     * @default 16
     */
    overflowPadding?: TooltipPrimitive.RootProps["overflowPadding"];
    /**
     * @default 14
     */
    arrowPadding?: TooltipPrimitive.RootProps["arrowPadding"];
}
export declare const HelpBubbleTooltipRoot: ForwardRefExoticComponent<HelpBubbleTooltipRootProps>;
export interface HelpBubbleTooltipTriggerProps extends TooltipPrimitive.TriggerProps {
}
export declare const HelpBubbleTooltipTrigger: ForwardRefExoticComponent<TooltipPrimitive.TriggerProps & RefAttributes<HTMLButtonElement>>;
export interface HelpBubbleTooltipDelayGroupProps extends TooltipPrimitive.DelayGroupProps {
}
export declare const HelpBubbleTooltipDelayGroup: typeof TooltipPrimitive.DelayGroup;
export interface HelpBubbleTooltipPositionerProps extends TooltipPrimitive.PositionerProps {
}
export declare const HelpBubbleTooltipPositioner: ForwardRefExoticComponent<HelpBubbleTooltipPositionerProps & RefAttributes<HTMLDivElement>>;
export interface HelpBubbleTooltipPositionerPortalProps extends TooltipPrimitive.PositionerPortalProps {
}
export declare const HelpBubbleTooltipPositionerPortal: ForwardRefExoticComponent<HelpBubbleTooltipPositionerPortalProps & RefAttributes<HTMLDivElement>>;
export interface HelpBubbleTooltipContentProps extends PrimitiveProps, Pick<StyleProps, "maxWidth">, React.HTMLAttributes<HTMLDivElement> {
}
export declare const HelpBubbleTooltipContent: ForwardRefExoticComponent<HelpBubbleTooltipContentProps & RefAttributes<HTMLDivElement>>;
export interface HelpBubbleTooltipArrowProps extends TooltipPrimitive.ArrowProps {
}
export declare const HelpBubbleTooltipArrow: ForwardRefExoticComponent<HelpBubbleTooltipArrowProps & RefAttributes<HTMLDivElement>>;
export interface HelpBubbleTooltipArrowTipProps extends React.SVGProps<SVGSVGElement> {
    /**
     * radius of the arrow tip
     * @default 2
     */
    tipRadius?: number;
}
export declare const HelpBubbleTooltipArrowTip: ForwardRefExoticComponent<Omit<HelpBubbleTooltipArrowTipProps, "ref"> & RefAttributes<SVGSVGElement>>;
export interface HelpBubbleTooltipBodyProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const HelpBubbleTooltipBody: ForwardRefExoticComponent<HelpBubbleTooltipBodyProps & RefAttributes<HTMLDivElement>>;
export interface HelpBubbleTooltipTitleProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const HelpBubbleTooltipTitle: ForwardRefExoticComponent<HelpBubbleTooltipTitleProps & RefAttributes<HTMLSpanElement>>;
export interface HelpBubbleTooltipDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const HelpBubbleTooltipDescription: ForwardRefExoticComponent<HelpBubbleTooltipDescriptionProps & RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=HelpBubbleTooltip.d.ts.map