import { MenuSheetVariantProps } from '@seed-design/css/recipes/menu-sheet';
import { MenuSheetItemVariantProps } from '@seed-design/css/recipes/menu-sheet-item';
import { Drawer } from '@seed-design/react-drawer';
import { PrimitiveProps } from '@seed-design/react-primitive';
import * as React from "react";
export interface SwipeableMenuSheetRootProps extends MenuSheetVariantProps, Pick<Drawer.RootProps, "children" | "open" | "defaultOpen" | "onOpenChange" | "closeOnEscape" | "closeOnInteractOutside" | "lazyMount" | "unmountOnExit" | "onAnimationEnd"> {
}
export declare function SwipeableMenuSheetRoot(props: SwipeableMenuSheetRootProps): import("react/jsx-runtime").JSX.Element;
export interface SwipeableMenuSheetTriggerProps extends Drawer.TriggerProps {
}
export declare const SwipeableMenuSheetTrigger: React.ForwardRefExoticComponent<Drawer.TriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface SwipeableMenuSheetPositionerProps extends Drawer.PositionerProps {
}
export declare const SwipeableMenuSheetPositioner: React.ForwardRefExoticComponent<SwipeableMenuSheetPositionerProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetBackdropProps extends Drawer.BackdropProps {
}
export declare const SwipeableMenuSheetBackdrop: React.ForwardRefExoticComponent<SwipeableMenuSheetBackdropProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetContentProps extends Drawer.ContentProps, Pick<MenuSheetItemVariantProps, "labelAlign"> {
}
export declare const SwipeableMenuSheetContent: React.ForwardRefExoticComponent<SwipeableMenuSheetContentProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetHandleProps extends PrimitiveProps, Omit<Drawer.HandleProps, "preventCycle"> {
}
export declare const SwipeableMenuSheetHandle: React.ForwardRefExoticComponent<SwipeableMenuSheetHandleProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetHeaderProps extends Drawer.HeaderProps {
}
export declare const SwipeableMenuSheetHeader: React.ForwardRefExoticComponent<SwipeableMenuSheetHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetTitleProps extends Drawer.TitleProps {
}
export declare const SwipeableMenuSheetTitle: React.ForwardRefExoticComponent<SwipeableMenuSheetTitleProps & React.RefAttributes<HTMLHeadingElement>>;
export interface SwipeableMenuSheetDescriptionProps extends Drawer.DescriptionProps {
}
export declare const SwipeableMenuSheetDescription: React.ForwardRefExoticComponent<SwipeableMenuSheetDescriptionProps & React.RefAttributes<HTMLParagraphElement>>;
export interface SwipeableMenuSheetListProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SwipeableMenuSheetList: React.ForwardRefExoticComponent<SwipeableMenuSheetListProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetGroupProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement>, Pick<MenuSheetItemVariantProps, "labelAlign"> {
}
export declare const SwipeableMenuSheetGroup: React.ForwardRefExoticComponent<SwipeableMenuSheetGroupProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetItemProps extends PrimitiveProps, MenuSheetItemVariantProps, React.HTMLAttributes<HTMLButtonElement> {
}
export declare const SwipeableMenuSheetItem: React.ForwardRefExoticComponent<SwipeableMenuSheetItemProps & React.RefAttributes<HTMLButtonElement>>;
export interface SwipeableMenuSheetItemContentProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SwipeableMenuSheetItemContent: React.ForwardRefExoticComponent<SwipeableMenuSheetItemContentProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetItemLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const SwipeableMenuSheetItemLabel: React.ForwardRefExoticComponent<SwipeableMenuSheetItemLabelProps & React.RefAttributes<HTMLSpanElement>>;
export interface SwipeableMenuSheetItemDescriptionProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const SwipeableMenuSheetItemDescription: React.ForwardRefExoticComponent<SwipeableMenuSheetItemDescriptionProps & React.RefAttributes<HTMLSpanElement>>;
export interface SwipeableMenuSheetFooterProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SwipeableMenuSheetFooter: React.ForwardRefExoticComponent<SwipeableMenuSheetFooterProps & React.RefAttributes<HTMLDivElement>>;
export interface SwipeableMenuSheetCloseButtonProps extends Drawer.CloseButtonProps {
}
/**
 * Visible button that closes the swipeable menu sheet.
 */
export declare const SwipeableMenuSheetCloseButton: React.ForwardRefExoticComponent<SwipeableMenuSheetCloseButtonProps & React.RefAttributes<HTMLButtonElement>>;
//# sourceMappingURL=SwipeableMenuSheet.d.ts.map