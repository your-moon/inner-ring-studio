export { LayoutContent as Content, LayoutRoot as Root, type LayoutContentProps as ContentProps, type LayoutRootProps as RootProps, } from './Layout';
//# sourceMappingURL=Layout.namespace.d.ts.map