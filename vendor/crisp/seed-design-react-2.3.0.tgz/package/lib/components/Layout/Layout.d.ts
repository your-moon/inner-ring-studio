import { PrimitiveProps } from '@seed-design/react-primitive';
import { LayoutVariantProps } from '@seed-design/css/recipes/layout';
import type * as React from "react";
export interface LayoutRootProps extends LayoutVariantProps, PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const LayoutRoot: React.ForwardRefExoticComponent<LayoutRootProps & React.RefAttributes<HTMLDivElement>>;
export interface LayoutContentProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const LayoutContent: React.ForwardRefExoticComponent<LayoutContentProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=Layout.d.ts.map