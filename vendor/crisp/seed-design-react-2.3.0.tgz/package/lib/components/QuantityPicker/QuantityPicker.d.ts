import { PrimitiveProps } from '@seed-design/react-primitive';
import { QuantityPicker as QuantityPickerPrimitive } from '@seed-design/react-quantity-picker';
import { QuantityPickerVariantProps } from '@seed-design/css/recipes/quantity-picker';
import * as React from "react";
export type QuantityPickerRootProps = Omit<QuantityPickerVariantProps, "size" | "layout"> & QuantityPickerPrimitive.RootProps & {
    /**
     * 컴포넌트의 크기입니다.
     * @default "medium"
     */
    size?: QuantityPickerVariantProps["size"];
    /**
     * 컴포넌트가 부모 Flex 레이아웃의 여유 공간을 채울지 지정합니다.
     * @since 2.2.0
     * @default "hug"
     */
    layout?: QuantityPickerVariantProps["layout"];
};
export declare const QuantityPickerRoot: React.ForwardRefExoticComponent<QuantityPickerRootProps & React.RefAttributes<HTMLDivElement>>;
interface QuantityPickerButtonProps extends PrimitiveProps, Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, "disabled" | "type"> {
    icon?: React.ReactNode;
    loadingIndicator?: React.ReactNode;
}
export interface QuantityPickerDecrementButtonProps extends Omit<QuantityPickerPrimitive.DecrementButtonProps, "children">, QuantityPickerButtonProps {
    removeIcon?: React.ReactNode;
}
export declare const QuantityPickerDecrementButton: React.ForwardRefExoticComponent<QuantityPickerDecrementButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface QuantityPickerValueDisplayProps extends QuantityPickerPrimitive.ValueDisplayProps {
}
export declare const QuantityPickerValueDisplay: React.ForwardRefExoticComponent<Omit<QuantityPickerValueDisplayProps & React.RefAttributes<HTMLSpanElement>, "ref"> & React.RefAttributes<HTMLSpanElement>>;
export interface QuantityPickerIncrementButtonProps extends Omit<QuantityPickerPrimitive.IncrementButtonProps, "children">, QuantityPickerButtonProps {
}
export declare const QuantityPickerIncrementButton: React.ForwardRefExoticComponent<QuantityPickerIncrementButtonProps & React.RefAttributes<HTMLButtonElement>>;
export interface QuantityPickerHiddenInputProps extends QuantityPickerPrimitive.HiddenInputProps {
}
export declare const QuantityPickerHiddenInput: React.ForwardRefExoticComponent<QuantityPickerPrimitive.HiddenInputProps & React.RefAttributes<HTMLInputElement>>;
export {};
//# sourceMappingURL=QuantityPicker.d.ts.map