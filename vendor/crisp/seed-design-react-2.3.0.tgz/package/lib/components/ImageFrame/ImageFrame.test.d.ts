export {};
//# sourceMappingURL=ImageFrame.test.d.ts.map