import { SideNavigation as SideNavigationPrimitive, UseSideNavigationItemProps, SideNavigationProviderProps as SideNavigationProviderPrimitiveProps } from '@seed-design/react-side-navigation';
import { SideNavigationVariantProps } from '@seed-design/css/recipes/side-navigation';
import { SideNavigationInsetVariantProps } from '@seed-design/css/recipes/side-navigation-inset';
import { SideNavigationMenuItemVariantProps } from '@seed-design/css/recipes/side-navigation-menu-item';
import { PrimitiveProps } from '@seed-design/react-primitive';
import { InternalIconProps } from '../private/Icon';
import { default as React } from 'react';
export interface SideNavigationProviderProps extends SideNavigationProviderPrimitiveProps {
}
export declare function SideNavigationProvider(props: SideNavigationProviderProps): import("react/jsx-runtime").JSX.Element;
export declare namespace SideNavigationProvider {
    var displayName: string;
}
export interface SideNavigationRootProps extends SideNavigationVariantProps, SideNavigationPrimitive.RootProps {
}
export declare const SideNavigationRoot: React.ForwardRefExoticComponent<SideNavigationRootProps & React.RefAttributes<HTMLElement>>;
export interface SideNavigationHeaderProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SideNavigationHeader: React.ForwardRefExoticComponent<SideNavigationHeaderProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationContentProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SideNavigationContent: React.ForwardRefExoticComponent<SideNavigationContentProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationFooterProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SideNavigationFooter: React.ForwardRefExoticComponent<SideNavigationFooterProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationGroupProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SideNavigationGroup: React.ForwardRefExoticComponent<SideNavigationGroupProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationGroupLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SideNavigationGroupLabel: React.ForwardRefExoticComponent<SideNavigationGroupLabelProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationItemProps extends SideNavigationMenuItemVariantProps, UseSideNavigationItemProps, PrimitiveProps, React.HTMLAttributes<HTMLButtonElement> {
}
export declare const SideNavigationItem: React.ForwardRefExoticComponent<SideNavigationItemProps & React.RefAttributes<HTMLButtonElement>>;
export interface SideNavigationItemLabelProps extends PrimitiveProps, React.HTMLAttributes<HTMLSpanElement> {
}
export declare const SideNavigationItemLabel: React.ForwardRefExoticComponent<SideNavigationItemLabelProps & React.RefAttributes<HTMLSpanElement>>;
export interface SideNavigationItemPrefixIconProps extends InternalIconProps {
}
export declare const SideNavigationItemPrefixIcon: React.ForwardRefExoticComponent<SideNavigationItemPrefixIconProps & React.RefAttributes<SVGSVGElement>>;
export interface SideNavigationItemSuffixIconProps extends InternalIconProps {
}
export declare const SideNavigationItemSuffixIcon: React.ForwardRefExoticComponent<SideNavigationItemSuffixIconProps & React.RefAttributes<SVGSVGElement>>;
export interface SideNavigationItemCollapsibleRootProps extends SideNavigationMenuItemVariantProps, SideNavigationPrimitive.ItemCollapsibleRootProps {
}
export declare const SideNavigationItemCollapsibleRoot: React.ForwardRefExoticComponent<SideNavigationItemCollapsibleRootProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationItemCollapsibleTriggerProps extends UseSideNavigationItemProps, SideNavigationPrimitive.ItemCollapsibleTriggerProps {
}
export declare const SideNavigationItemCollapsibleTrigger: React.ForwardRefExoticComponent<SideNavigationItemCollapsibleTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface SideNavigationItemCollapsibleContentProps extends SideNavigationPrimitive.ItemCollapsibleContentProps {
}
export declare const SideNavigationItemCollapsibleContent: React.ForwardRefExoticComponent<SideNavigationItemCollapsibleContentProps & React.RefAttributes<HTMLDivElement>>;
export interface SideNavigationTriggerProps extends SideNavigationPrimitive.TriggerProps {
}
export declare const SideNavigationTrigger: React.ForwardRefExoticComponent<SideNavigationTriggerProps & React.RefAttributes<HTMLButtonElement>>;
export interface SideNavigationInsetProps extends SideNavigationInsetVariantProps, PrimitiveProps, React.HTMLAttributes<HTMLDivElement> {
}
export declare const SideNavigationInset: React.ForwardRefExoticComponent<SideNavigationInsetProps & React.RefAttributes<HTMLDivElement>>;
//# sourceMappingURL=SideNavigation.d.ts.map