import { Breakpoint } from '@seed-design/css/breakpoints';
type ResponsiveObject<T> = {
    [K in Breakpoint]?: T;
} & (T extends object ? {
    [K in Exclude<keyof T & string, Breakpoint>]?: never;
} : {});
export type ResponsiveValue<T> = T | ResponsiveObject<T>;
export type UnwrapResponsive<T> = T extends ResponsiveValue<infer U> ? U : T;
export type BreakpointThreshold = Exclude<Breakpoint, "base">;
export declare function isResponsiveObject<T>(value: ResponsiveValue<T>): value is ResponsiveObject<T>;
export {};
//# sourceMappingURL=responsive.d.ts.map