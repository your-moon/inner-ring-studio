import { Breakpoint } from '@seed-design/css/breakpoints';
import { ResponsiveValue } from '../types/responsive';
import { UseBreakpointOptions } from './useBreakpoint';
export declare function resolveResponsiveValue<T>(values: {
    [K in Breakpoint]?: T;
}, breakpoint: Breakpoint): T | undefined;
export declare function useBreakpointValue<T>(values: ResponsiveValue<T>, options?: UseBreakpointOptions): T | undefined;
//# sourceMappingURL=useBreakpointValue.d.ts.map