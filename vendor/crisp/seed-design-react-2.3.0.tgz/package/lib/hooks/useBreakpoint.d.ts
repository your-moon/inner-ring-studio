import { Breakpoint } from '@seed-design/css/breakpoints';
import { Context } from 'react';
export interface UseBreakpointOptions {
    defaultBreakpoint?: Breakpoint;
}
export interface BreakpointContextValue {
    breakpoint: Breakpoint;
    defaultBreakpoint: Breakpoint;
}
export declare const BreakpointContext: Context<BreakpointContextValue | null>;
export declare function useBreakpoint(options?: UseBreakpointOptions): Breakpoint;
//# sourceMappingURL=useBreakpoint.d.ts.map