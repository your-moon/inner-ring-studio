import { Breakpoint } from '@seed-design/css/breakpoints';
type Listener = () => void;
export declare function subscribe(listener: Listener): () => void;
export declare function getSnapshot(): Breakpoint;
export declare function getServerSnapshot(): Breakpoint;
export {};
//# sourceMappingURL=breakpoint-store.d.ts.map