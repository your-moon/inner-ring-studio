import { ScopedColorBg, ScopedColorFg, ScopedColorPalette, ScopedColorStroke, Dimension, Radius, SpacingX, SpacingY, Gradient, Shadow, ScopedColorBanner } from '@seed-design/css/vars';
import { ResponsiveValue } from '../types/responsive';
import { ForwardRefExoticComponent, PropsWithoutRef, RefAttributes } from 'react';
export declare function resolveResponsive<T>(varName: string, value: ResponsiveValue<T>, transform: (v: T) => string | number | undefined): Record<string, string | number>;
export declare function handleColor(color: string | undefined): any;
export declare function handleDimension(dimension: string | 0 | undefined): string | undefined;
export declare function handleRadius(radius: string | 0 | undefined): any;
interface MarginStyleProps {
    /**
     * Margin on all four sides.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    margin?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `margin`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    m?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Horizontal margin (left + right).
     *
     * Cannot be combined with any `bleed*` prop.
     */
    marginX?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `marginX`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    mx?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Vertical margin (top + bottom).
     *
     * Cannot be combined with any `bleed*` prop.
     */
    marginY?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `marginY`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    my?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Top margin.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    marginTop?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `marginTop`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    mt?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Right margin.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    marginRight?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `marginRight`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    mr?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Bottom margin.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    marginBottom?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `marginBottom`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    mb?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Left margin.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    marginLeft?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
    /**
     * Shorthand for `marginLeft`.
     *
     * Cannot be combined with any `bleed*` prop.
     */
    ml?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "auto" | (string & {})>;
}
interface BleedStyleProps {
    /**
     * Negative margin on all four sides to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleed?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Negative x-axis margin to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleedX?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Negative y-axis margin to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleedY?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Negative top margin to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleedTop?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Negative right margin to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleedRight?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Negative bottom margin to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleedBottom?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Negative left margin to extend the element outside its parent.
     * If set to "asPadding", it will use the padding value in the same direction.
     *
     * Cannot be combined with any `margin*` prop.
     */
    bleedLeft?: ResponsiveValue<"asPadding" | Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
}
/** Distributes `Omit` over each union branch, preserving the union structure. */
export type DistributiveOmit<T, K extends PropertyKey> = T extends unknown ? Omit<T, K> : never;
/**
 * Margin and bleed props both resolve to CSS `margin-*` values, so they
 * are mutually exclusive at the type level — pick one family, not both.
 */
export type StyleProps = {
    /**
     * Shorthand for `background`.
     */
    bg?: ScopedColorBg | ScopedColorPalette | ScopedColorBanner | (string & {});
    background?: ScopedColorBg | ScopedColorPalette | ScopedColorBanner | (string & {});
    /**
     * Shorthand for `backgroundGradient`.
     */
    bgGradient?: Gradient;
    backgroundGradient?: Gradient;
    /**
     * Shorthand for `backgroundGradientDirection`.
     * e.g. `43deg`
     */
    bgGradientDirection?: "to right" | "to left" | "to top" | "to bottom" | "to top right" | "to top left" | "to bottom right" | "to bottom left" | (string & {});
    /**
     * e.g. `43deg`
     */
    backgroundGradientDirection?: "to right" | "to left" | "to top" | "to bottom" | "to top right" | "to top left" | "to bottom right" | "to bottom left" | (string & {});
    color?: ScopedColorFg | ScopedColorPalette | (string & {});
    borderColor?: ScopedColorStroke | ScopedColorPalette | (string & {});
    borderWidth?: 0 | 1 | (string & {});
    borderTopWidth?: 0 | 1 | (string & {});
    borderRightWidth?: 0 | 1 | (string & {});
    borderBottomWidth?: 0 | 1 | (string & {});
    borderLeftWidth?: 0 | 1 | (string & {});
    borderRadius?: Radius | 0 | (string & {});
    borderTopLeftRadius?: Radius | 0 | (string & {});
    borderTopRightRadius?: Radius | 0 | (string & {});
    borderBottomRightRadius?: Radius | 0 | (string & {});
    borderBottomLeftRadius?: Radius | 0 | (string & {});
    boxShadow?: Shadow | (string & {});
    width?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | "full" | (string & {})>;
    minWidth?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | "full" | (string & {})>;
    maxWidth?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | "full" | (string & {})>;
    height?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | "full" | (string & {})>;
    minHeight?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | "full" | (string & {})>;
    maxHeight?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | "full" | (string & {})>;
    top?: 0 | (string & {});
    left?: 0 | (string & {});
    right?: 0 | (string & {});
    bottom?: 0 | (string & {});
    padding?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Shorthand for `padding`.
     */
    p?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    paddingX?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Shorthand for `paddingX`.
     */
    px?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    paddingY?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Shorthand for `paddingY`.
     */
    py?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    paddingTop?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "safeArea" | (string & {})>;
    /**
     * Shorthand for `paddingTop`.
     */
    pt?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "safeArea" | (string & {})>;
    paddingRight?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Shorthand for `paddingRight`.
     */
    pr?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    paddingBottom?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "safeArea" | (string & {})>;
    /**
     * Shorthand for `paddingBottom`.
     */
    pb?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | "safeArea" | (string & {})>;
    paddingLeft?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    /**
     * Shorthand for `paddingLeft`.
     */
    pl?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    display?: ResponsiveValue<"block" | "flex" | "grid" | "inline-flex" | "inline" | "inline-block" | "none">;
    position?: "relative" | "absolute" | "fixed" | "sticky";
    overflowX?: "visible" | "hidden" | "scroll" | "auto";
    overflowY?: "visible" | "hidden" | "scroll" | "auto";
    zIndex?: number | (string & {});
    /**
     * If true, flex-grow will be set to `1`.
     */
    flexGrow?: 0 | 1 | (number & {}) | true;
    /**
     * If true, flex-shrink will be set to `1`.
     */
    flexShrink?: 0 | (number & {}) | true;
    flexDirection?: ResponsiveValue<"row" | "column" | "row-reverse" | "column-reverse">;
    /**
     * If true, flex-wrap will be set to `wrap`.
     */
    flexWrap?: "wrap" | "wrap-reverse" | "nowrap" | true;
    justifyContent?: "flex-start" | "flex-end" | "center" | "space-between" | "space-around";
    /**
     * In flexbox layout, this property is ignored.
     */
    justifySelf?: "center" | "start" | "end" | "stretch";
    alignItems?: "flex-start" | "flex-end" | "center" | "stretch";
    alignContent?: "flex-start" | "flex-end" | "center" | "stretch";
    alignSelf?: "flex-start" | "flex-end" | "center" | "stretch";
    gap?: ResponsiveValue<Dimension | `spacingX.${SpacingX}` | `spacingY.${SpacingY}` | 0 | (string & {})>;
    gridColumn?: string;
    gridRow?: string;
    unstable_transform?: string;
    _active?: {
        bg?: ScopedColorBg | ScopedColorPalette | (string & {});
        background?: ScopedColorBg | ScopedColorPalette | (string & {});
    };
} & ((BleedStyleProps & {
    [K in keyof MarginStyleProps]?: never;
}) | (MarginStyleProps & {
    [K in keyof BleedStyleProps]?: never;
}));
type UseStyleProps = StyleProps & {
    style?: React.CSSProperties;
};
export declare function useStyleProps<T extends UseStyleProps>(props: T): {
    style: React.CSSProperties;
    restProps: Omit<T, keyof UseStyleProps>;
};
export declare function withStyleProps<P extends {}, R>(Component: React.ComponentType<P & React.RefAttributes<R>>): ForwardRefExoticComponent< PropsWithoutRef<P> & RefAttributes<R>>;
export {};
//# sourceMappingURL=styled.d.ts.map