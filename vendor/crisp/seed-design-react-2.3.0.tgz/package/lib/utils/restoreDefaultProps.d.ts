/** Restores defaults overwritten by explicitly passed undefined values. */
export declare function restoreDefaultProps<P>(props: Record<string, unknown>, defaultProps: Partial<P> | undefined): void;
//# sourceMappingURL=restoreDefaultProps.d.ts.map