/**
 * Builds the SVG path for a HelpBubble arrow tip given its measured size.
 * Shared by HelpBubble (dialog) and HelpBubbleTooltip (tooltip) so the arrow
 * geometry stays in a single place.
 */
export declare const getHelpBubbleArrowTipPath: (width: number, height: number, tipRadius: number) => string;
//# sourceMappingURL=getHelpBubbleArrowTipPath.d.ts.map