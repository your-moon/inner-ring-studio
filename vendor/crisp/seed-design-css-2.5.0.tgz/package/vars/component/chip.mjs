export const vars = {
  "base": {
    "enabled": {
      "root": {
        "colorDuration": "var(--seed-duration-color-transition)",
        "colorTimingFunction": "var(--seed-timing-function-easing)",
        "cornerRadius": "var(--seed-radius-full)"
      },
      "prefixIcon": {
        "paddingLeft": "var(--seed-dimension-x1_5)"
      },
      "prefixAvatar": {
        "size": "var(--seed-dimension-x6)"
      },
      "suffixIcon": {
        "paddingRight": "var(--seed-dimension-x1_5)"
      },
      "label": {
        "fontWeight": "var(--seed-font-weight-medium)",
        "paddingX": "var(--seed-dimension-x1_5)"
      },
      "icon": {
        "color": "var(--seed-color-fg-neutral)"
      }
    }
  },
  "variantSolid": {
    "enabled": {
      "root": {
        "color": "var(--seed-color-bg-neutral-weak-alpha)"
      },
      "label": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "prefixIcon": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "suffixIcon": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "icon": {
        "color": "var(--seed-color-fg-neutral)"
      }
    },
    "pressed": {
      "root": {
        "color": "var(--seed-color-bg-neutral-weak-alpha-pressed)"
      }
    },
    "disabled": {
      "root": {
        "opacity": "0.5"
      }
    },
    "selected": {
      "root": {
        "color": "var(--seed-color-bg-neutral-inverted)"
      },
      "label": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      },
      "prefixIcon": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      },
      "suffixIcon": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      },
      "icon": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      }
    },
    "selectedPressed": {
      "root": {
        "color": "var(--seed-color-bg-neutral-inverted-pressed)"
      }
    },
    "selectedDisabled": {
      "root": {
        "opacity": "0.5"
      }
    }
  },
  "variantOutlineStrong": {
    "enabled": {
      "root": {
        "color": "var(--seed-color-bg-transparent)",
        "strokeColor": "var(--seed-color-stroke-neutral-muted)",
        "strokeWidth": "1px"
      },
      "label": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "prefixIcon": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "suffixIcon": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "icon": {
        "color": "var(--seed-color-fg-neutral)"
      }
    },
    "pressed": {
      "root": {
        "color": "var(--seed-color-bg-transparent-pressed)"
      }
    },
    "disabled": {
      "root": {
        "opacity": "0.5"
      }
    },
    "selected": {
      "root": {
        "color": "var(--seed-color-bg-neutral-inverted)"
      },
      "label": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      },
      "prefixIcon": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      },
      "suffixIcon": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      },
      "icon": {
        "color": "var(--seed-color-fg-neutral-inverted)"
      }
    },
    "selectedPressed": {
      "root": {
        "color": "var(--seed-color-bg-neutral-inverted-pressed)"
      }
    },
    "selectedDisabled": {
      "root": {
        "opacity": "0.5"
      }
    }
  },
  "variantOutlineWeak": {
    "enabled": {
      "root": {
        "color": "var(--seed-color-bg-transparent)",
        "strokeColor": "var(--seed-color-stroke-neutral-muted)",
        "strokeWidth": "1px"
      },
      "label": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "prefixIcon": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "suffixIcon": {
        "color": "var(--seed-color-fg-neutral)"
      },
      "icon": {
        "color": "var(--seed-color-fg-neutral)"
      }
    },
    "pressed": {
      "root": {
        "color": "var(--seed-color-bg-transparent-pressed)"
      }
    },
    "disabled": {
      "root": {
        "opacity": "0.5"
      }
    },
    "selected": {
      "root": {
        "strokeColor": "var(--seed-color-stroke-neutral-contrast)",
        "color": "var(--seed-color-bg-neutral-weak)"
      }
    },
    "selectedPressed": {
      "root": {
        "color": "var(--seed-color-bg-neutral-weak-pressed)"
      }
    },
    "selectedDisabled": {
      "root": {
        "opacity": "0.5"
      }
    }
  },
  "sizeSmall": {
    "enabled": {
      "root": {
        "height": "32px",
        "paddingX": "var(--seed-dimension-x1_5)"
      },
      "label": {
        "fontSize": "var(--seed-font-size-t4)",
        "lineHeight": "var(--seed-line-height-t4)"
      },
      "prefixIcon": {
        "size": "var(--seed-dimension-x3_5)"
      },
      "suffixIcon": {
        "size": "var(--seed-dimension-x3_5)"
      },
      "prefixAvatar": {
        "size": "var(--seed-dimension-x5)"
      },
      "icon": {
        "size": "var(--seed-dimension-x3_5)"
      }
    }
  },
  "sizeMedium": {
    "enabled": {
      "root": {
        "height": "36px",
        "paddingX": "var(--seed-dimension-x2)"
      },
      "label": {
        "fontSize": "var(--seed-font-size-t4)",
        "lineHeight": "var(--seed-line-height-t4)"
      },
      "prefixIcon": {
        "size": "var(--seed-dimension-x4)"
      },
      "suffixIcon": {
        "size": "var(--seed-dimension-x3_5)"
      },
      "prefixAvatar": {
        "size": "var(--seed-dimension-x6)"
      },
      "icon": {
        "size": "var(--seed-dimension-x4)"
      }
    }
  },
  "sizeLarge": {
    "enabled": {
      "root": {
        "height": "40px",
        "paddingX": "var(--seed-dimension-x2_5)"
      },
      "label": {
        "fontSize": "var(--seed-font-size-t4)",
        "lineHeight": "var(--seed-line-height-t4)"
      },
      "prefixIcon": {
        "size": "var(--seed-dimension-x4)",
        "paddingLeft": "var(--seed-dimension-x1_5)"
      },
      "suffixIcon": {
        "size": "var(--seed-dimension-x4)"
      },
      "prefixAvatar": {
        "size": "var(--seed-dimension-x7)"
      },
      "icon": {
        "size": "var(--seed-dimension-x4)"
      }
    }
  },
  "sizeSmallLayoutWithText": {
    "enabled": {
      "root": {
        "minWidth": "44px"
      }
    }
  },
  "sizeMediumLayoutWithText": {
    "enabled": {
      "root": {
        "minWidth": "var(--seed-dimension-x12)"
      }
    }
  },
  "sizeLargeLayoutWithText": {
    "enabled": {
      "root": {
        "minWidth": "var(--seed-dimension-x13)"
      }
    }
  },
  "sizeSmallLayoutIconOnly": {
    "enabled": {
      "root": {
        "minWidth": "var(--seed-dimension-x8)"
      }
    }
  },
  "sizeMediumLayoutIconOnly": {
    "enabled": {
      "root": {
        "minWidth": "var(--seed-dimension-x9)"
      }
    }
  },
  "sizeLargeLayoutIconOnly": {
    "enabled": {
      "root": {
        "minWidth": "var(--seed-dimension-x10)"
      }
    }
  }
}