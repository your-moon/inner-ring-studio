export const vars = {
  "base": {
    "enabled": {
      "root": {
        "height": "80px",
        "color": "var(--seed-color-bg-transparent)",
        "cornerRadius": "var(--seed-radius-r3)",
        "strokeWidth": "1px",
        "gap": "var(--seed-dimension-x2_5)"
      },
      "thumbnail": {
        "color": "var(--seed-color-bg-neutral-weak)",
        "size": "var(--seed-dimension-x12)",
        "cornerRadius": "var(--seed-radius-r2)"
      },
      "thumbnailIcon": {
        "color": "var(--seed-color-fg-neutral-subtle)",
        "size": "var(--seed-dimension-x6)"
      },
      "name": {
        "color": "var(--seed-color-fg-neutral)",
        "fontSize": "var(--seed-font-size-t2)",
        "lineHeight": "var(--seed-line-height-t2)",
        "fontWeight": "var(--seed-font-weight-medium)"
      },
      "size": {
        "color": "var(--seed-color-fg-neutral-subtle)",
        "fontSize": "var(--seed-font-size-t1)",
        "lineHeight": "var(--seed-line-height-t1)",
        "fontWeight": "var(--seed-font-weight-regular)"
      },
      "removeButtonMask": {
        "offset": "var(--seed-dimension-x1_5)",
        "size": "var(--seed-dimension-x6)"
      }
    }
  },
  "typeFile": {
    "enabled": {
      "root": {
        "width": "160px",
        "strokeColor": "var(--seed-color-stroke-neutral-weak)",
        "paddingX": "var(--seed-dimension-x4)"
      }
    },
    "readonly": {
      "thumbnailIcon": {
        "color": "var(--seed-color-fg-disabled)"
      },
      "name": {
        "color": "var(--seed-color-fg-disabled)"
      },
      "size": {
        "color": "var(--seed-color-fg-disabled)"
      }
    },
    "dragging": {
      "thumbnailIcon": {
        "color": "var(--seed-color-fg-disabled)"
      },
      "name": {
        "color": "var(--seed-color-fg-disabled)"
      },
      "size": {
        "color": "var(--seed-color-fg-disabled)"
      }
    }
  },
  "typeImage": {
    "enabled": {
      "root": {
        "width": "80px",
        "strokeColor": "var(--seed-color-stroke-neutral-subtle)"
      },
      "backdrop": {
        "color": "var(--seed-color-bg-overlay)"
      },
      "badge": {
        "color": "var(--seed-color-bg-overlay)",
        "height": "var(--seed-dimension-x6)",
        "cornerRadius": "var(--seed-radius-r3)",
        "paddingX": "var(--seed-dimension-x1)"
      },
      "badgeLabel": {
        "color": "var(--seed-color-palette-static-white)",
        "fontSize": "var(--seed-font-size-t2)",
        "lineHeight": "var(--seed-line-height-t2)",
        "fontWeight": "var(--seed-font-weight-medium)"
      }
    },
    "readonly": {
      "root": {
        "opacity": "0.5"
      }
    },
    "dragging": {
      "root": {
        "opacity": "0.5"
      }
    }
  }
}