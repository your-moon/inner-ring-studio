export declare const vars: {
  "base": {
    "enabled": {
      "root": {
        "cornerRadius": "var(--seed-radius-full)",
        "strokeColor": "var(--seed-color-stroke-neutral-subtle)"
      }
    }
  },
  /**
   * 대표 사용처: 댓글을 남긴 사용자
   */
  "size20": {
    "enabled": {
      "root": {
        "size": "20px",
        "strokeWidth": "1px"
      }
    }
  },
  /**
   * 대표 사용처: 답글 프로필
   */
  "size24": {
    "enabled": {
      "root": {
        "size": "24px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "14px",
        "size": "12px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "15px",
        "size": "10px"
      }
    }
  },
  /**
   * 대표 사용처: 댓글 프로필
   */
  "size36": {
    "enabled": {
      "root": {
        "size": "36px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "20px",
        "size": "18px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "22px",
        "size": "14px"
      }
    }
  },
  /**
   * 대표 사용처: 게시글 상세 내 프로필
   */
  "size42": {
    "enabled": {
      "root": {
        "size": "42px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "24px",
        "size": "20px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "26px",
        "size": "16px"
      }
    }
  },
  /**
   * 대표 사용처: 작은 리스트
   */
  "size48": {
    "enabled": {
      "root": {
        "size": "48px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "28px",
        "size": "22px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "30px",
        "size": "18px"
      }
    }
  },
  /**
   * 대표 사용처: 큰 리스트
   */
  "size56": {
    "enabled": {
      "root": {
        "size": "56px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "34px",
        "size": "24px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "36px",
        "size": "20px"
      }
    }
  },
  /**
   * 대표 사용처: 프로필 상세, 캐러셀
   */
  "size64": {
    "enabled": {
      "root": {
        "size": "64px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "40px",
        "size": "26px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "42px",
        "size": "22px"
      }
    }
  },
  "size80": {
    "enabled": {
      "root": {
        "size": "80px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "52px",
        "size": "32px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "54px",
        "size": "28px"
      }
    }
  },
  "size96": {
    "enabled": {
      "root": {
        "size": "96px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "62px",
        "size": "38px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "65px",
        "size": "32px"
      }
    }
  },
  /**
   * 대표 사용처: 프로필 수정
   */
  "size108": {
    "enabled": {
      "root": {
        "size": "108px",
        "strokeWidth": "1px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badgeMask": {
        "offset": "70px",
        "size": "44px"
      },
      /** size=20에서는 지원되지 않습니다. */
      "badge": {
        "offset": "74px",
        "size": "36px"
      }
    }
  }
}